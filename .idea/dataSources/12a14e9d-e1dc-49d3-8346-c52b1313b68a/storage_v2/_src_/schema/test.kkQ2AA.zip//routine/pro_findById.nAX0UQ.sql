CREATE PROCEDURE pro_findById(IN sid INT)
  begin
select * from student where id = sid;
end;


CREATE PROCEDURE add_pro(IN a INT, IN b INT, OUT sum INT)
  begin
set sum = a+b;
end;

